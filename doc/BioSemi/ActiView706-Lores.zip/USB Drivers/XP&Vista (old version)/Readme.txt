Install the driver by right clicking on the file 'BioSemi.inf'
Then select 'Install'