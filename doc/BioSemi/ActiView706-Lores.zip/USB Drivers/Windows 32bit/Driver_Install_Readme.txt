Install the driver by right clicking on the file 'BioSemiWinUsb2.INF'
Then select 'Install'

If this doesn't work, follow the "Manual Installation" steps below.

Manual Installation
===================

When the USB cable is plugged into the computer's USB
slot, a kernel mode driver must be chosen to handle the I/O.  
On XP32, Vista32 and Win7-32 this driver can be either the BioSemi or
the Microsoft driver.  On Win7-64 and Vista64 the Microsoft driver must be
used.  Here's the usual sequence of displays and what you should
chose.


XP32 (i.e. XP)
----
Open the Control Panel
	Select: System, Hardware, Device Manager
Plugin the USB cable.

If the Found New Hardware Wizard window doesn't appear, right click
on the existing driver listed (you may have to expand the "Devices Class"
entry in the list), select the "Update Driver" menu item and the
Hardware Update Wizard window will appear.  If there is no existing
driver, double click "Add Hardware" in the Control Panel.

Make the following selections:

	"Can Windows connect to Windows Update to search for software?"
		Select "No, not this time".

	"What do you want the wizard to do?"
		Select "Install from a list or specific location (Advanced)."

	"Please choose your search and installation options."
		Select "Don't search. I will choose the driver to install."

	"Select the device driver you want to install for this hardware."
		Select a driver from the list shown or choose "Have Disk".

	"Install From Disk"
		Use "Browse" to select the directory with the INF file to use.


Vista32, Vista64, Win7-32, Win7-64
----------------------------------
Open the Control Panel
	Select: Device Manager
Plugin the USB cable.

If the wrong driver is installed for this device, right click on the
existing driver listed (you may have to expand a class to see the driver
entry in the list), select the "Uninstall" menu item and a "Confirm
Device Uninstall" window will appear.  Select "Delete the driver software
for this device" and click "OK".  Pull out the USB cable and re-insert it.
If there is no existing driver, double click "Add Hardware" in the
Control Panel.

Now you should see the following sequence of displays:

"Windows needs to install driver software for your Receiver01"
	Select "Locate and install driver software (recommended)"

After a short pause while it searches Windows Update you get:

"Insert the disk that came with your RECEIVER01"
	Select "I don't have the disk. Show me other options."

"Windows couldn't find software for your device."
	Select "Browse my computer for driver software (advanced)"

"Browse for driver software on your computer"
	Use "Browse" to select the directory with the INF file to use.

"Windows can't verify the publisher of this driver software"
	Select "Install this driver software anyway"

