ActiABR is used for measuring Auditory Brainstem Response functions.
The AD-box will have to be equipped with the BioSemi ABR input and set at speedmode 9.
Also, special ABR electrodes are needed for doing an ABR measurement.